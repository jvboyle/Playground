# Date: 20161210
# Version: 1.2
# By: robertson@br.ibm.com

#!/bin/bash

DEVICE_LIST="device-list"
DEVICE_CMDS="device-commands"
OUTPUT="output"
FILE=".getcmd.exp"
STANDARD_FILE=".getcmd.exp.standard"

cat $DEVICE_LIST | sed -e '/^#/d' -e '/^$/d'| while read DEVICE; do
		HOSTNAME=`echo $DEVICE | awk -F";" '{print $1}'`;
		HOST=`echo $DEVICE | awk -F";" '{print $2}'`;
		METHOD=`echo $DEVICE | awk -F";" '{print $3}'`;
		PORT=`echo $DEVICE | awk -F";" '{print $4}'`;
		USER=`echo $DEVICE | awk -F";" '{print $5}'`;
		USER_PASSWORD=`echo $DEVICE | awk -F";" '{print $6}'`;
		ENABLE=`echo $DEVICE | awk -F";" '{print $6}'`;
		EN_PASSWORD=`echo $DEVICE | awk -F";" '{print $7}'`;


	# Setting connection port
	sed -i "s/PORT/$PORT/g" $FILE

	if [ "$ENABLE" == "enable" ]; then
		/usr/bin/expect $FILE -h $HOST -u $USER -p $USER_PASSWORD -e $EN_PASSWORD -m $METHOD -f $DEVICE_CMDS | tee $OUTPUT/$HOSTNAME.txt
	fi

	if [ "$ENABLE" != "enable" ]; then
		/usr/bin/expect $FILE -h $HOST -u $USER -p $USER_PASSWORD -m $METHOD -f $DEVICE_CMDS | tee $OUTPUT/$HOSTNAME.txt
	fi

	# Restoring the standard file
	cp $STANDARD_FILE $FILE
done
exit 0
