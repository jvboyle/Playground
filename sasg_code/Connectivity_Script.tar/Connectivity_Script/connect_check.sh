#!/bin/bash
########################################################################
# Description: Connection test script                                  #
# Author: Svyatlana Dubrouskaya                                        #
# Date: 2017.02.10                                                     # 
# Version: 1.1                                                         #
# Config: connect_check.param                                          #
#                                                                      #
# History:                                                             #
#    2017.02.10 - Original script.                                     # 
#    2017.05.26 - Added vyos support; default connections;             #
#                                                                      #
# Notes:                                                               #
#    Make sure "connect_check.param" is in the script directory.       #
########################################################################
set -o verbose

function check_bash
{

   timeout 1 bash -c "cat < /dev/null > /dev/tcp/$1/$2"
   if [ $? -eq 0 ]; then
      echo "connected" | tee -a $LogFile
   else
        echo "no access" | tee -a $LogFile
   fi
}

function check_nc
{
   if [ "$2" == "53" ]; then
      check_var=$(echo "" | nc -vu -w 5 $1 $2 2>&1 | grep -E "refused|timed out|No route")
   else
      check_var=$(echo "" | nc -v -w 5 $1 $2 2>&1 | grep -E "refused|timed out|No route")
   fi
   if [ "$check_var" == "" ]; then
      echo "connected" | tee -a $LogFile
   else
      echo "no access" | tee -a $LogFile
   fi
}

function create_param_file
{
   echo "#########################################################################" > $Param_file
   echo "# Description: Parameter File for connect_check.sh script               #" >> $Param_file
   echo "# !!!This file is mandatory and must be located in the same directory   #" >> $Param_file
   echo "# as the connect_check.sh script and its name can not be changed.!!!    #" >> $Param_file
   echo "#########################################################################" >> $Param_file
   echo $1
   end_line=$(grep -n "$1" connect_check.param.template | grep END | awk -F':' '{print $1}')
   start_line=$(grep -n "$1" connect_check.param.template | grep -v END | awk -F':' '{print $1}')
   head -n $end_line connect_check.param.template | tail -n +$start_line >> $Param_file
   if [ "$1" == "CUSTOMER" ]; then
     for ((INDEX=0; INDEX<${#DNS_IP[@]}; INDEX++))
      do
      DNS=${DNS_IP[INDEX]}
      LDAP=${LDAP_IP[INDEX]}
      echo "DNS server;${DNS_IP[INDEX]};53"    >> $Param_file                                       
      echo "LDAP server;${LDAP_IP[INDEX]};636" >> $Param_file
      done
   fi 

}

Date=`date +"%Y-%m-%d %H:%M (%Z)"`
LogFile="connect_check.log"
Param_file="connect_check.param"
Result_file="connect_check.html"

MS_BPM_IP="10.148.11.182"
MS_CHEF_IP="10.148.11.187"
MS_EE_IP="10.148.11.147"
MS_ASB_IP="10.148.11.160"
MS_DTR="10.148.11.133"

echo "-----------------------------------" > $LogFile
echo "$Date : Start script" >> $LogFile
echo "-----------------------------------" >> $LogFile
cat > $Result_file <<- _EOF_
    <HTML>
    <HEAD>
        <TITLE>
        Test connection results
        </TITLE>
    </HEAD>
   <BODY>
     <h3>Results of the test connectivity script</h3>
     <style>
       table, th, td {
       border: 1px solid black;
       border-collapse: collapse;
      }
    </style>
    <table class="editorDemoTable">
    <thead>
 	<tr>
    	<td>Server type</td>
    	<td>IP adress</td>
    	<td>Port</td>
    	<td>Result</td>
   	 </tr>
    </thead>
<tbody>
_EOF_

source ./vars
ip -f inet -o address | while read -r line; do
   ip=$(echo $line | cut -d\  -f 4 | cut -d/ -f 1)
   case $ip in
   $PRIVATE_VYOS_IP|$BPM_IP|$CHEF_IP|$EE_IP|$ASB_IP|$RCP_BPM_IP|$RCP_ROR_IP) create_param_file "CUSTOMER"
   break
   ;;
   $MS_VYATTA_IP|$MS_BPM_IP|$MS_CHEF_IP|$MS_EE_IP|$MS_ASB_IP|$MS_R1SOFT_IP|$MS_BIGFIX_IP|$MS_DTR|$MS_APIE_IP) create_param_file "MANAGEMENT"
   break
   ;;
   esac
done

nc_command=$(which nc)
if [ "$nc_command" != "" ]; then
   check="nc"
else
   check="bash"
fi
echo $check
echo 
cat $Param_file | grep -v -E "^\s*#" | grep -v -E "^\s*$" | while read line 
do
   echo "Processing line $line" | tee -a $LogFile
   Type=$(echo $line | cut -f1 -d";")
   IP=$(echo $line | cut -f2 -d";")
   Port=$(echo $line | cut -f3 -d";")
   echo "check_$check $IP $Port"
   Result=$(check_$check $IP $Port) 
   echo "<tr>" >> $Result_file
   echo "<td>$Type</td>" >> $Result_file
   echo "<td> $IP </td>" >> $Result_file
   echo "<td> $Port </td>" >> $Result_file
   echo " <td> $Result </td>" >> $Result_file
   echo "</tr>" >> $Result_file
   echo "" >> $LogFile
done 

echo "</tbody>" >> $Result_file
echo "</table>" >> $Result_file
echo "</BODY>"  >> $Result_file
echo "</HTML>" >> $Result_file
echo "-----------------------------------" >> $LogFile
Date=`date +"%Y-%m-%d %H:%M (%Z)"`
echo "$Date : End Script" >> $LogFile
echo "-----------------------------------" >> $LogFile
