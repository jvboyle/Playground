package Page;
use Exporter;

use strict;
use Cell;
use Cfg;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);
@EXPORT = qw(page);

sub page
{
  my $max;

  for (`lsps -s`)
  {
    s/^\s+|\s+$//;
    next unless /^\d+/;
    ($max) = /^(\d+)MB\s+\d+/;
  }

  my %page = (page => cell(Key => "page", Title => "Paging Space"));
  
  cfg(KEY => "page", TITLE => "Paging Space", MAX => $max,
      OPTIONS => "gauge", IN => "Used", OUT => "Available",
      INLONG => "Used Paging Space", OUTLONG => "Available Paging Space",
      YLEG => "Paging Space", SHORT => "MB",
      TARGET =>
         '`/sasg/MRTG/scripts/page.pl`'
     );
  return %page;
}
