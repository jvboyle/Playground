#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  $cron = `ps -aef|grep "/usr/sbin/cron"|grep -v grep`;
  $cron =~ s/^\s+|\s+$//g;
  $cron = (split(/\s+/,$cron))[1];
  for (`ps -aef|grep $cron|grep -v grep`)
  {
     @cron = split(/\s+/,$_);
     next unless $cron[2] == $cron;
     $x++;
  }

  print "0\n$x\n";
  print localtime()."\n";
  print "Cron Jobs\n";
};

if ($@ =~ /timeout/) { exit };
