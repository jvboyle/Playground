#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  @result = grep {/Mem/} `/usr/bin/free -b`;

  ($x,$y) = (split(/\s+/,$result[0]))[1,2];

  print "$y\n$x\n";
  print localtime()."\n";
  print "Memory\n";
};

if ($@ =~ /timeout/) { exit };
