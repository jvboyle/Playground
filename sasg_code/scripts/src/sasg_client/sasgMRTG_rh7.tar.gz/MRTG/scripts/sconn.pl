#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{
  ($y = `ps -aef|grep "\/usr\/sHTTPServer\/bin\/httpd"|grep -v grep|wc -l`)
     =~ s/^\s+|\s+$//g;
  ($x = `netstat -an|grep ESTAB|egrep "\\\.8080 |\\\.7443 |\\\.8443 "|wc -l`) =~ s/^\s+|\s+$//g;

  print "$x\n$y\n";
  print localtime()."\n";
  print "Surrogate HTTP Sessions\n";
};

if ($@ =~ /timeout/) { exit }

