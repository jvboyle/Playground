#!/usr/bin/perl

alarm(20);
eval
{
  $pid = open LSVG,"lsvg datavg|";
  @lsvg = <LSVG>;
  close LSVG;
  alarm(0);
};
if ($@ =~ /timeout/) { kill(9,$pid) };

for (@lsvg)
{
  if (/TOTAL PPs:[^(]+\((\d+)/)
  {
    $max = $1;
  }
  if (/USED PPs:[^(]+\((\d+)/)
  {
    $used = $1;
  }
}

print "$used\n$max\n";
print scalar(localtime),"\n";
print "datavg\n";
