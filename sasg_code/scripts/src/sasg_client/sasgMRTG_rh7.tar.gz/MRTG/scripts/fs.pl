#!/usr/bin/perl

$starthtml = q{
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
    <TITLE>MRTG Index Page</TITLE>
<META HTTP-EQUIV="Refresh" CONTENT="600" >
</HEAD>

<BODY bgcolor="#ffffff" text="#000000" link="#000000" vlink="#000000" alink="#000000">
<H1>MRTG Index Page</H1>

<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=10>
};

$cellhtml = q{
<TD><DIV><B>%FSNAME%</B></DIV>
<DIV><A HREF="%FS%.html "><IMG BORDER=1 ALT="%FSNAME%" SRC="%FS%-day.png"></A>
<BR><SMALL><!--#flastmod file="%FS%.html" --></SMALL></DIV></TD>
};

$endhtml = q{
</TABLE>
<BR>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR>
    <TD WIDTH=63><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-l.png" WIDTH=63 HEIGHT=25 ALT="MRTG"></A></TD>
    <TD WIDTH=25><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-m.png" WIDTH=25 HEIGHT=25 ALT=""></A></TD>
    <TD WIDTH=388><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-r.png" WIDTH=388 HEIGHT=25
    ALT="Multi Router Traffic Grapher"></A></TD>
  </TR>
</TABLE>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR VALIGN=top>
  <TD WIDTH=88 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
  version 2.9.4</FONT></TD>
  <TD WIDTH=388 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
  <A HREF="http://www.ee.ethz.ch/~oetiker/">Tobias Oetiker</A>
  <A HREF="mailto:oetiker@ee.ethz.ch">&lt;oetiker@ee.ethz.ch&gt;</A>
  and&nbsp;<A HREF="http://www.bungi.com/">Dave&nbsp;Rand</A>&nbsp;<A HREF="mailto:dlr@bungi.com">&lt;dlr@bungi.com&gt;</A></FONT>
  </TD>
</TR>
</TABLE>
</BODY>
</HTML>
};

$header = q{
WorkDir: /sasg/MRTG/htdocs/stats/fs/
WriteExpires: Yes
Language: english
};

$footer = q{
MaxBytes[datavg]: %MAX%
Target[datavg]: `/sasg/MRTG/bin/fstotal.pl`;
Title[datavg]: Total Volume Group Usage: datavg
PageTop[datavg]: <h1>Total datavg Volume Group usage</h1>
Options[datavg]:  gauge
YLegend[datavg]: Blocks
ShortLegend[datavg]: Blocks
Legend1[datavg]: 1024 byte blocks
Legend2[datavg]: 1024 byte blocks
};

$fsStanza = q{
MaxBytes[%FS%]: %MAX%
Target[%FS%]: `/sasg/MRTG/bin/filesystem.pl %FSNAME%`;
Title[%FS%]: %FSNAME%
PageTop[%FS%]: <h1>File System %FSNAME% usage</h1>
Options[%FS%]:  gauge
YLegend[%FS%]: Blocks
ShortLegend[%FS%]: Blocks
Legend1[%FS%]: 1024 byte blocks
Legend2[%FS%]: 1024 byte blocks
};

@df = `df -k`;
shift @df;

open CONF,">/sasg/MRTG/conf/fs.cfg";
open HTML,">/sasg/MRTG/htdocs/stats/fs/index.html";

print CONF $header;
print HTML $starthtml;
print HTML "<TR>\n";

for (@df)
{
  ($max,$free,$name) = (split)[1,2,-1];
  ($key = $name) =~ s!/!.!g;
  $key =~ s/^\.+//g;
  $key = "root" unless $key;
  $used = $max - $free;
  $temp = $fsStanza;
  $temphtml = $cellhtml;
  s/%FS%/$key/g for ($temp,$temphtml);
  s/%FSNAME%/$name/g for ($temp,$temphtml);
  $temp =~ s/%MAX%/$max/g;
  print CONF $temp;
  print HTML $temphtml;
  $totalmax += $max;
  $totalused += $used;
  if ($completerow) { print HTML "</TR>"; $completerow = 0; }
  else { $completerow = 1; }
}

$footer =~ s/%MAX%/$totalmax/;
print CONF $footer;;
$cellhtml =~ s/%FS%/datavg/g;
$cellhtml =~ s/%FSNAME%/datavg/g;
print HTML $cellhtml;
print HTML "</TR>\n";

close CONF;
close HTML;
exit;


