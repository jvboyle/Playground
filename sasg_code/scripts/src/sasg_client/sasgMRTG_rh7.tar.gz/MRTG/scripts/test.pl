#! /usr/bin/perl
# -*- mode: Perl -*-

###################################################################
# MRTG 2.9.4  Multi Router Traffic Grapher
###################################################################
# Created by Tobias Oetiker <oetiker@ee.ethz.ch>
#            and Dave Rand <dlr@bungi.com>
#
# For individual Contributers check the CHANGES file
#
###################################################################
#
# Distributed under the GNU General Public License
#
###################################################################

@main::DEBUG=qw();
# DEBUG TARGETS
# cfg  - watch the config file reading
# dir  - directory mangeling
# base - basic program flow
# tarp - target parser
# snpo - snmp polling
# fork - forking view
# time - some timing info
# log  - logging of data via rateup or rrdtool
$main::GRAPHFMT="png";
# There older perls tend to behave peculiar with
# large integers ...
require 5.005;

use strict;

BEGIN {
    # Automatic OS detection ... do NOT touch
    if ( $^O =~ /^(ms)?(dos|win(32|nt)?)/i ) {
	$main::OS = 'NT';
	$main::SL = '\\';
	$main::PS = ';';
    } elsif ( $^O =~ /^VMS$/i ) {
	$main::OS = 'VMS';
	$main::SL = '.';
	$main::PS = ':';
    } else {
	$main::OS = 'UNIX';
	$main::SL = '/';
	$main::PS = ':';
    }
}

use FindBin;
use lib "${FindBin::Bin}";
use lib "${FindBin::Bin}${main::SL}..${main::SL}lib${main::SL}mrtg2";
use Getopt::Long;

# search for binaries in the bin and bin/../lib  directory
use MRTG_lib "2.090006";
use SNMP_Session "0.77";
use BER "0.77";
use SNMP_util "0.77";
use locales_mrtg "0.07";

$main::STARTTIME = time;

if ($MRTG_lib::OS eq 'UNIX') {
    $SIG{HUP} = $SIG{INT} = $SIG{TERM} = 
           sub {   unlink ${main::Cleanfile} 
                       if($main::Cleanfile);
                   unlink ${main::Cleanfile2} 
                       if($main::Cleanfile2);
                   die "ERROR: Bailout after SIG $_[0]\n";
                };
}


END {
    local($?, $!);
    unlink ${main::Cleanfile} if($main::Cleanfile);
    unlink ${main::Cleanfile2} if($main::Cleanfile2);
}

&main;

exit(0);

#### Functions ################################################

sub main {

    debug 'time', "prog start ".localtime(time);

    # read in the config file
    my @routers;
    my %cfg;
    my %rcfg;
    my %opts;
    GetOptions(\%opts, 'user=s', 'group=s');
    if (defined $opts{user}) {
        my $uid = getpwnam($opts{user}) or die "ERROR: Unknown User: $opts{user})\n";
        ($<,$>) = ($uid,$uid);
        die "ERROR faild to set UID to $uid\n" unless ($< == $uid and  $> == $uid);
    }
    if (defined $opts{group}) {
        my $gid = getgrnam($opts{group}) or die "ERROR: Unknown Group: $opts{group})\n";
        ($(,$)) = ($gid,$gid);
    }

    my $cfgfile = shift @ARGV;
    printusage() unless defined $cfgfile;

    # lets make sure that there are not two mrtgs running in parallel.
    # so we lock on the cfg file. Nothing fancy, just a lockfile

    my $lockfile = $cfgfile."_l";
    my $templock = $cfgfile."_l_" . $$ ;

    debug('base', "Creating Lockfiles $lockfile,$templock");
    &lockit($lockfile,$templock);

    debug('base', "Reading Config File: $cfgfile");
    readcfg($cfgfile,\@routers,\%cfg,\%rcfg);

    for my $thresh (qw(threshmini threshmaxi threshmino threshmaxo))
    {
      next unless exists $rcfg{$thresh};
      for my $target (sort keys %{$rcfg{$thresh}})
      {
        $rcfg{$thresh}{$target} = eval $rcfg{$thresh}{$target};
      }
    }
    for my $key (sort keys %rcfg)
    {
       print "$key =>\n";
       for my $akey (sort keys %{$rcfg{$key}})
       {
          print "\t$akey => $rcfg{$key}{$akey}\n";
       }
    }

    # from our last run we kept some info about
    # the configuration of our devices around
    debug('base', "Reading Interface Config cache");
    my $confcachefile = $cfgfile;
    $confcachefile  =~ s/\.[^.\/]+$//;
    $confcachefile .= ".ok";
    my $confcache = readconfcache($confcachefile);

    # Check the config and create the target object
    debug('base', "Checking Config File");
    my @target;
    cfgcheck(\@routers, \%cfg, \%rcfg, \@target);

    # postload rrdtool support
    if ($cfg{logformat} eq 'rrdtool'){
        debug('base', "Loading RRD support");
	require 'RRDs.pm';
    }

    # set the locale
    my $LOC;
    if ( $cfg{'language'} && defined($lang2tran::LOCALE{"\L$cfg{'language'}\E"})) {
	debug('base', "Loading Locale for ".$cfg{'language'});
	$LOC=$lang2tran::LOCALE{"\L$cfg{'language'}\E"};
    } else {
	debug('base', "Loading default Locale");
	$LOC=$lang2tran::LOCALE{'default'};
    }

    # Deamon Code
    my $last_time=0;
    my $curent_time;
    my $sleep_time;
    my $pidfile = $cfgfile;
    $pidfile =~ s/\.[^.\/]+$//;
    $pidfile .= '.pid';
    &demonize_me($pidfile) if $cfg{'runasdaemon'} =~ /y/i  and $MRTG_lib::OS ne 'VMS';
    
    debug('base', "Starting main Loop");
    do {                        # Do this loop once for native mode and forever in daemon mode 
        my $router;
        debug 'time', "loop start ".localtime(time);

        #if we run as daemin, we sleep in between collection cycles
        $sleep_time=  ($cfg{interval}*60)-(time-$last_time);
        if ($sleep_time > 0 ) { #If greater than 0 the sleep that amount of time
	    debug('time', "Sleep time $sleep_time seconds");
            sleep ($sleep_time);
        } elsif ($last_time > 0) {
            warn "WARNING: data collection did not complete within interval!\n";
        }
        $last_time=time;

        # set meta expires if there is an index file
        # 2000/05/03 Bill McGonigle <bill@zettabyte.net>
        if (defined $cfg{'writeexpires'}) {
           my $exp = &expistr($cfg{'interval'} ? $cfg{'interval'} : 5);
           my $fil;
           $fil = "$cfg{'htmldir'}index.html.meta"  if -e "$cfg{'htmldir'}index.html";
           $fil = "$cfg{'htmldir'}index.htm.meta"  if -e "$cfg{'htmldir'}index.html";
            if (defined $fil) {
                   open(META, ">$fil.meta");
                   print META "Expires: $exp\n";
                   close(META);
            }
        }


        # Use SNMP to populate the target object
	debug('base', "Populate Target object by polling SNMP and".
	      " external Datasources");
        debug 'time', "snmp read start ".localtime(time);
        readtargets($confcache,\@target, \%cfg);

        # collect data for each router or pseudo target (`executable`)
        debug 'time', "target loop start ".localtime(time);
        foreach $router (@routers) {
	    debug('base', "Act on Router/Target $router");
            if (defined $rcfg{'setenv'}{$router}) {
                my $line = $rcfg{'setenv'}{$router};
                while ( $line =~ s/([^=]+)="([^"]+)"\s*// ) {
                    $ENV{$1}=$2;
                }
            }
            my($savetz) = $ENV{'TZ'};
            if (defined $rcfg{'timezone'}{$router}) {
                $ENV{'TZ'} = $rcfg{'timezone'}{$router}
            }

            my ($inlast, $outlast, $uptime, $name, $time) = 
              getcurrent(\@target, $router, \%rcfg);
	    debug('base', "Get Current values: ($inlast, $outlast, $uptime, $name, $time)");

            #abort, if the router is not responding.
            next unless defined $inlast and defined $outlast;

            my ($maxin, $maxout, $maxpercent, $avin, $avout, $avpercent,
                $cuin, $cuout, $cupercent);
	    debug('base', "Create Graphics");
            if ($rcfg{'options'}{'dorelpercent'}{$router}) {
                ($maxin, $maxout, $maxpercent, $avin, $avout, $avpercent,
                 $cuin, $cuout, $cupercent) =
                   writegraphics($router, \%cfg, \%rcfg, $inlast, $outlast, $time);
            } else {
                ($maxin, $maxout ,$avin, $avout, $cuin, $cuout) =
                  writegraphics($router, \%cfg, \%rcfg, $inlast, $outlast, $time);
            }

	    debug('base', "Check for Thresholds");
            threshcheck(\%cfg,\%rcfg,$cfgfile,$router,$cuin,$cuout)
                if defined $cuin and defined $cuout and 
                   ( defined $cfg{threshprogi} or
                     defined $cfg{threshprogo} or  
                     defined $cfg{threshdir} );


	    if ($cfg{logformat} eq 'rateup'){

		debug('base', "Check for Write HTML Pages");
		writehtml($router, \%cfg, \%rcfg,
			  $maxin, $maxout, $maxpercent, $avin, $avout, $avpercent,
			  $cuin, $cuout, $cupercent, $uptime, $name, $LOC)
	    }

            #put TZ things back in shape ... 
            if ($savetz) {
                $ENV{'TZ'} =  $savetz;
            } else {
                delete $ENV{'TZ'};
            }
            ;
        }
    } while ($cfg{'runasdaemon'} =~ /y/i ); #In daemon mode run forever
    debug('base', "Exit main Loop");
    # OK we are done, remove the lock files ... 

    debug('base', "Remove Lock Files");
    close LOCK; unlink ($templock, $lockfile);

    debug('base', "Store Interface Config Cache");
    delete $$confcache{___updated} if exists $$confcache{___updated}; # make sure everything gets written out not only the updated entries
    writeconfcache($confcache,$confcachefile)
}


sub getcurrent {
    my ($target, $rou, $rcfg) = @_;

    my $inlast;
    my $outlast;
    my $uptime;
    my $name;
    my $strg;
    my $time;
    my $count=0;


    $inlast = eval("my \$mode='_IN_';$$rcfg{target}{$rou}");
    if (defined $inlast and $inlast != $inlast * 1 or $@) {
	die "ERROR: Target[$rou] eval warning: $@\n" if $@;
        $inlast = undef;
	warn "WARNING: Target[$rou]: $$rcfg{targorig}{$rou} did not evaluate to an integer";
    };
    $outlast = eval("my \$mode='_OUT_';$$rcfg{target}{$rou}");
    if (defined $outlast and $outlast != $outlast * 1 or $@) {
	die "ERROR: Target[$rou] eval warning: $@\n" if $@;
        $outlast = undef;
	warn "WARNING: Target[$rou]: $$rcfg{targorig}{$rou} did not evaluate to an integer";
    };

    if ($$rcfg{target}{$rou} =~ /^\s*\$\$target\[\d+\]{\$mode}\s*$/) {
        $uptime = eval("my \$mode='_UPTIME_';$$rcfg{target}{$rou}");
        $name = eval("my \$mode='_NAME_';$$rcfg{target}{$rou}");
	die "ERROR: Target[$rou] eval warning: $@\n" if $@;
        $time = eval("my \$mode='_TIME_';$$rcfg{target}{$rou}");
	die "ERROR: Target[$rou] eval warning: $@\n" if $@;
    }
    #make sure we have a time set ...
    $time = time unless defined $time and $time =~ /^\d+$/;

    if (defined $$rcfg{routeruptime}{$rou}) {
        ($uptime,$name) = &snmpget($$rcfg{routeruptime}{$rou},
                                   'sysUptime',
                                   'sysName'); #" <- this makes emacs parsing happy
    }

    ($inlast, $outlast, $uptime, $name, $time);
}


sub writegraphics {
    my($router, $cfg, $rcfg, $inlast, $outlast, $time) = @_;
  
    my($absmax,$maxv, $maxvi, $maxvo, $i, $period, $res);
    my(@exec, @mxvls, @metas);
    my(%maxin, %maxout, %maxpercent, %avin, %avout, %avpercent, %cuin, %cuout, %cupercent);

    @metas = ();
    $maxvi = $$rcfg{'maxbytes1'}{$router};
    $maxvo = $$rcfg{'maxbytes2'}{$router};
    if ($maxvi > $maxvo) {
        $maxv = $maxvi;
    } else {
        $maxv = $maxvo;
    }
    $absmax = $$rcfg{'absmax'}{$router};
    $absmax = $maxv unless defined $absmax;
    if ($absmax < $maxv) {
        die "ERROR: AbsMax: $absmax is smaller than MaxBytes: $maxv\n";
    }

    if (length($inlast) > 190 or length($outlast) > 190 ) {
        die "ERROR: Inlast: '$inlast' or Outlast: '$outlast' is way to long ...";
    }

    # select whether the datasource gives relative or absolte return values.
    my $up_abs="u";
    $up_abs='a' if defined $$rcfg{'options'}{'absolute'}{$router};
    $up_abs='g' if defined $$rcfg{'options'}{'gauge'}{$router};
    $up_abs='h' if defined $$rcfg{'options'}{'perhour'}{$router};
    $up_abs='m' if defined $$rcfg{'options'}{'perminute'}{$router};

    if ($$cfg{logformat} eq 'rrdtool') {
        debug('base',"start RRDtool section");
        # make sure we got some sane default here
        my %dstype = qw/u COUNTER a ABSOLUTE g GAUGE h COUNTER m COUNTER/;
        $up_abs = $dstype{$up_abs};
        # update the database.
        my $rrd = "$$cfg{'logdir'}$$rcfg{'directory'}{$router}$router.rrd";
        # set minimum/maximum values. use 'U' if we cannot get good values
        # the lower bound is hardcoded to 0
        my $absi = $maxvi;
        my $abso = $maxvo;
        $absi = $abso = $$rcfg{'absmax'}{$router}
            if defined $$rcfg{'absmax'}{$router};
        debug('base',"maxi:$absi, maxo:$abso");
        $absi = 'U' if $absi == 0;
        $abso = 'U' if $abso == 0;
        # maybe we can convert an .log file to the new rrd format
        if (-e "$$cfg{'logdir'}$$rcfg{'directory'}{$router}$router.log"
            and not -e "$rrd") {
             debug('base',"converting $$cfg{'logdir'}$$rcfg{'directory'}{$router}$router.log to RRD format");
             if($RRDs::VERSION < 1.000271){
                die "ERROR: RRDtool version 1.0.27 or later required to perform log2rrd conversion\n";
             }
             log2rrd($router,$cfg,$rcfg);
        } elsif (! -e $rrd) {
            #nope it seems we have to create a new one
            debug('base',"create $rrd");
            # create the rrd if it doesn't exist
            # don't fail if interval is not set
            my $interval = $$cfg{interval} || 5;
            my $minhb = int($$cfg{interval} * 60)*2;
            $minhb = 600 if ($minhb <600);
            my @args = ($rrd, '-b', $time-10, '-s', int($interval * 60),
                         "DS:ds0:$up_abs:$minhb:0:$absi",
                         "DS:ds1:$up_abs:$minhb:0:$abso",
                         "RRA:AVERAGE:0.5:1:600",
                         "RRA:AVERAGE:0.5:6:700",
                         "RRA:AVERAGE:0.5:24:775",
                         "RRA:AVERAGE:0.5:288:797",
                         "RRA:MAX:0.5:1:600",
                         "RRA:MAX:0.5:6:700",
                         "RRA:MAX:0.5:24:775",
                         "RRA:MAX:0.5:288:797");
            RRDs::create(@args);
            my $e = RRDs::error();
            die "ERROR: Cannot create logfile: $e\n" if $e;
            debug('log', "Called: RRDs::create(@args)");
        } else {
            # update the minimum/maximum according to maxbytes/absmax
            # and (re)set the data-source-type to reflect cfg changes
            # cost: 1 read/write cycle, but update will reuse the buffered data
            my @args = ($rrd, '-a', "ds0:$absi", '-a', "ds1:$abso",
                       '-d', "ds0:$up_abs", '-d', "ds1:$up_abs");
            RRDs::tune(@args);
            my $e = RRDs::error();
            die "ERROR: Cannot tune logfile: $e\n" if $e;
            debug('log', "Called: RRDs::tune(@args)");
        }
        # update the rrd
        $inlast = 'U' unless defined $inlast;
        $outlast = 'U' unless defined $outlast;
        RRDs::update("$rrd", "$time:$inlast:$outlast");
        my $e = RRDs::error(); 
        die "ERROR: Cannot update $rrd with '$time:$inlast:$outlast' $e\n" if ($e);
        debug('log', "Called: RRDs::update($rrd, '$time:$inlast:$outlast')");

        # get the rrdtool-processed values back from rrdtool
        # for the threshold checks (we cannot use the fetched data)
        my $lasttime = RRDs::last($rrd);
        $e = RRDs::error(); 
        die "ERROR: Cannot 'last' $rrd: $e\n" if ($e);
        debug('log', "Called: RRDs::last()");
        my @fetch = RRDs::fetch($rrd,'AVERAGE','-s',$lasttime,'-e',$lasttime);
        $e = RRDs::error(); 
        die "ERROR: Cannot 'fetch' $rrd: $e\n" if ($e);
        debug('log', "Called: RRDs::fetch($rrd,'AVERAGE','-s',$lasttime,'-e',$lasttime)");
        debug('log', "  got: $fetch[3][0][0]/$fetch[3][0][1]");
        $cuin{'d'}{$router} = $fetch[3][0][0];
        $cuout{'d'}{$router} = $fetch[3][0][1];
        # the html pages and the graphics are created at "call time" so that's it!
        # (the returned hashes are empty, it's just to minimize the changes to mrtg)
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            return (\%maxin, \%maxout, \%maxpercent, \%avin, \%avout, \%avpercent, \%cuin, \%cuout, \%cupercent);
        }
        return (\%maxin, \%maxout, \%avin, \%avout, \%cuin, \%cuout);

    }                 
    ########## rrdtool users have left here ###############

    ((($MRTG_lib::OS eq 'NT') && (-e "${FindBin::Bin}${MRTG_lib::SL}rateup.exe")) ||
     (-x "${FindBin::Bin}${MRTG_lib::SL}rateup")) || 
       die "ERROR: Can't Execute '${FindBin::Bin}${MRTG_lib::SL}rateup'\n";

    # rateup does not know about undef so we make inlast and outlast ready for rateup
    $inlast = -1 unless defined $inlast;
    $outlast = -1 unless defined $outlast;

    if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
        @exec = ("${FindBin::Bin}${MRTG_lib::SL}rateup", 
                 "$$cfg{'logdir'}$$rcfg{'directory'}{$router}","$router",
                 $time, $$rcfg{'options'}{'unknaszero'}{$router} ? '-z':'-Z',
                 "$up_abs"."p", $inlast, $outlast, $absmax,
                 "C", $$rcfg{'rgb1'}{$router},$$rcfg{'rgb2'}{$router},
                 $$rcfg{'rgb3'}{$router},$$rcfg{'rgb4'}{$router},
                 $$rcfg{'rgb5'}{$router});
    } else { 
        @exec = ("${FindBin::Bin}${MRTG_lib::SL}rateup", 
                 "$$cfg{'logdir'}$$rcfg{'directory'}{$router}","$router",
                 $time, $$rcfg{'options'}{'unknaszero'}{$router} ? '-z':'-Z',
                 "$up_abs", $inlast, $outlast, $absmax,
                 "c", $$rcfg{'rgb1'}{$router},$$rcfg{'rgb2'}{$router},
                 $$rcfg{'rgb3'}{$router},$$rcfg{'rgb4'}{$router});
    }

    push (@exec, '-t') if defined $$rcfg{'options'}{'transparent'}{$router};
    push (@exec, '-0') if defined $$rcfg{'options'}{'withzeroes'}{$router};

    my $maxx = $$rcfg{'xsize'}{$router}; 
    my $maxy = $$rcfg{'ysize'}{$router};
    my $xscale = $$rcfg{'xscale'}{$router}; 
    my $yscale = $$rcfg{'yscale'}{$router}; 
    my $growright = 0+($$rcfg{'options'}{'growright'}{$router} or 0);
    my $bits = 0+($$rcfg{'options'}{'bits'}{$router} or 0);
    my $integer = 0+($$rcfg{'options'}{'integer'}{$router} or 0);
    my $step = 5*60; 
    my $rop;
    my $ytics = $$rcfg{'ytics'}{$router};
    my $yticsf= $$rcfg{'yticsfactor'}{$router};

    if ($$rcfg{'ylegend'}{$router}) {
        push (@exec, "l", "[$$rcfg{'ylegend'}{$router}]");
    }
    my $sign = ($$rcfg{'unscaled'}{$router} && $$rcfg{'unscaled'}{$router} =~ /d/) ? 1 : -1;
  
    if ($$rcfg{'kilo'}{$router}) {
        push (@exec, "k", $$rcfg{'kilo'}{$router});
    }
    if ($$rcfg{'kmg'}{$router}) { 
        push (@exec, "K", $$rcfg{'kmg'}{$router});
    }
    if ($$rcfg{'weekformat'}{$router}) {
        push (@exec, "W", $$rcfg{'weekformat'}{$router});
    }
    if ($$rcfg{'suppress'}{$router} !~ /d/) {
        # VMS: should work for both now
        push (@exec, "i", "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-day.${main::GRAPHFMT}",
              $sign*$maxvi, $sign*$maxvo, $maxx, $maxy, ,$xscale, $yscale, $growright, $step, $bits, $ytics, $yticsf);
        @mxvls = ("d");
        push (@metas, "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-day.${main::GRAPHFMT}",
              $$cfg{'interval'} ? $$cfg{'interval'} : 5);
    }
    my $SAGE = (time - $main::STARTTIME) / 3600 / 24; # current script age 

    if (((not -e "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-week.${main::GRAPHFMT}") ||
         ((-M "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-week.${main::GRAPHFMT}") + $SAGE  >= 0.5/24)) &&
        ($$rcfg{'suppress'}{$router} !~/w/)
       ) {
        $step=30*60;
        $sign = ($$rcfg{'unscaled'}{$router} =~ /w/) ? 1 : -1;
        push (@mxvls , "w");
        $rop =($$rcfg{'withpeak'}{$router} =~ /w/) ? "p" : "i"; 
        push (@exec, $rop ,"$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-week.${main::GRAPHFMT}",
              $sign*$maxvi, $sign*$maxvo,  $maxx, $maxy, $xscale, $yscale, $growright, $step, $bits, $ytics, $yticsf);
        push (@metas, "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-week.${main::GRAPHFMT}", 30);
    }
  
    if (((not -e "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-month.${main::GRAPHFMT}") ||
         (( -M "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-month.${main::GRAPHFMT}") + $SAGE >= 2/24))  &&
        ($$rcfg{'suppress'}{$router} !~/m/)) {
        $step=2*60*60;
        $sign = ($$rcfg{'unscaled'}{$router} =~ /m/) ? 1 : -1;
        push (@mxvls , "m");
        $rop =($$rcfg{'withpeak'}{$router} =~ /m/) ? "p" : "i"; 
        push (@exec, $rop ,"$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-month.${main::GRAPHFMT}",
              $sign*$maxvi, $sign*$maxvo, $maxx, $maxy, $xscale, $yscale, $growright, $step, $bits, $ytics, $yticsf);
        push (@metas, "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-month.${main::GRAPHFMT}", 120);
    }
  
    if (((not -e "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-year.${main::GRAPHFMT}") ||
         (( -M "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-year.${main::GRAPHFMT}") + $SAGE  >= 1)) &&
        ($$rcfg{'suppress'}{$router} !~/y/)) {
        $step=24*60*60;
        $sign = ($$rcfg{'unscaled'}{$router} =~ /y/) ? 1 : -1;
        push (@mxvls , "y");
        $rop =($$rcfg{'withpeak'}{$router} =~ /y/) ? "p" : "i"; 
        push (@exec, $rop, "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-year.${main::GRAPHFMT}",
              $sign*$maxvi, $sign*$maxvo, $maxx, $maxy, $xscale, $yscale, $growright, $step, $bits, $ytics, $yticsf) ;
        push (@metas, "$$cfg{'imagedir'}$$rcfg{'directory'}{$router}${router}-year.${main::GRAPHFMT}", 1440);
    }

    # VMS: this might work now ... or does VMS NOT know about pipes?
    # NT doesn't have fork() so an open(xxx,"-|") won't work

    if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
        open (RATEUP, join (" ", @exec)."|");
    } else {
        open (RATEUP,"-|") ||  exec @exec;
    }
    debug('log', "Called @exec");

    if (open (HTML,"<$$cfg{'htmldir'}$$rcfg{'directory'}{$router}$router.$$rcfg{'extension'}{$router}")) {
        for ($i=0 ; $i<40 ; $i++) {
            $_=<HTML>;
            if (/<!-- maxin ([dwmy]) (\d*)/) {
                $maxin{$1}{$router}=0+$2;
            }

            if (/<!-- maxout ([dwmy]) (\d*)/) {
                $maxout{$1}{$router}=0+$2;
            }

            if (/<!-- maxpercent ([dwmy]) (\d*)/) {
                $maxpercent{$1}{$router}=0+$2;
            }

            if (/<!-- avin ([dwmy]) (\d*)/) {
                $avin{$1}{$router}=0+$2;
            }

            if (/<!-- avout ([dwmy]) (\d*)/) {
                $avout{$1}{$router}=0+$2;
            }

            if (/<!-- avpercent ([dwmy]) (\d*)/) {
                $avpercent{$1}{$router}=0+$2;
            }

            if (/<!-- cuin ([dwmy]) (\d*)/) {
                $cuin{$1}{$router}=0+$2;
            }

            if (/<!-- cuout ([dwmy]) (\d+)/) {
                $cuout{$1}{$router}=0+$2;
            }
     
            if (/<!-- cupercent ([dwmy]) (\d+)/) {
                $cupercent{$1}{$router}=0+$2;
            }
        }
        close HTML;
    }
  
  
    foreach $period (@mxvls) {
        chomp($res = <RATEUP>); 
        $maxin{$period}{$router}=sprintf("%.0f",0+$res);
        chomp($res = <RATEUP>); 

        $maxout{$period}{$router}=sprintf("%.0f",0+$res);
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            chomp($res = <RATEUP>); 
            $maxpercent{$period}{$router}=sprintf("%.0f",0+$res);
        }
        chomp($res = <RATEUP>); 
        $avin{$period}{$router}=sprintf("%.0f",0+$res);
        chomp($res = <RATEUP>); 
        $avout{$period}{$router}=sprintf("%.0f",0+$res);
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            chomp($res = <RATEUP>); 
            $avpercent{$period}{$router}=sprintf("%.0f",0+$res);
        }
        chomp($res = <RATEUP>); 
        $cuin{$period}{$router}=sprintf("%.0f",0+$res);
        chomp($res = <RATEUP>); 

        $cuout{$period}{$router}=sprintf("%.0f",0+$res);
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            chomp($res = <RATEUP>); 
            $cupercent{$period}{$router}=sprintf("%.0f",0+$res);
        }
    }
    close(RATEUP);
    if ($?) {
        my $value = $?;
        my $signal =  $? & 127; #ignore the most significant bit 
                                #as it is always one when it is a returning
                                #child says dave ...
        if (($MRTG_lib::OS != 'UNIX') || ($signal != 127)) {
            my $exitval = $? >> 8;
            warn "WARNING: rateup died from Signal $signal\n".
              " with Exit Value $exitval when doing router '$router'\n".
                " Signal was $signal, Returncode was $exitval\n"
        }
    }
    if ( $$cfg{'writeexpires'} =~ /^y/i ) {
        my($fil,$exp);
        while ( $fil = shift(@metas) ) {
            $exp = &expistr(shift(@metas));
            open(META, ">$fil.meta");
            print META "Expires: $exp\n";
            close(META);
        }
    }

    if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
        (\%maxin, \%maxout, \%maxpercent, \%avin, \%avout, \%avpercent, \%cuin, \%cuout, \%cupercent);
    } else {
        (\%maxin, \%maxout, \%avin, \%avout, \%cuin, \%cuout);
    }
}

#format 10*$kilo to 10 kB/s
sub fmi {
    my($number, $maxbytes, $router, @foo) = @_;
    my($rcfg,$LOC)=@foo;
    my(@short,$mul);
    if ($$rcfg{'kmg'}{$router}) {
        my($i);
        if ($$rcfg{'options'}{'bits'}{$router} == 1) {
            @short = ();
            foreach $i (split(/,/, $$rcfg{'kmg'}{$router})) {
                if ($$rcfg{'options'}{'perminute'}{$router}) {
                    $short[$#short+1] = "$i".&$LOC("b/min");
                } elsif ($$rcfg{'options'}{'perhour'}{$router}) {
                    $short[$#short+1] = "$i".&$LOC("b/h");
                } else {
                    $short[$#short+1] = "$i".&$LOC("b/s");
                }
            }
            $mul= 8;
        } else {
            @short = ();
            foreach $i (split(/,/, $$rcfg{'kmg'}{$router})) {
                if ($$rcfg{'options'}{'perminute'}{$router}) {
                    $short[$#short+1] = "$i".&$LOC ("B/min");
                } elsif ($$rcfg{'options'}{'perhour'}{$router}) {
                    $short[$#short+1] = "$i".&$LOC("B/h");
                } else {
                    $short[$#short+1] = "$i".&$LOC("B/s");
                }
            }
            $mul= 1;
        }
        if (defined $$rcfg{'shortlegend'}{$router}) {
            @short = ();
            foreach $i (split(/,/, $$rcfg{'kmg'}{$router})) {
                $short[$#short+1] = "$i"."$$rcfg{'shortlegend'}{$router}";
            }
        }
    } else {
        if (defined $$rcfg{'options'}{'bits'}{$router}) {
            if ($$rcfg{'options'}{'perminute'}{$router}) {
                @short = (&$LOC("b/min"),&$LOC("kb/min"),&$LOC("Mb/min"),&$LOC("Gb/min"));
            } elsif (defined $$rcfg{'options'}{'perhour'}{$router}) {
                @short = (&$LOC("b/h"),&$LOC("kb/h"),&$LOC("Mb/h"),&$LOC("Gb/h"));
            } else {
                @short = (&$LOC("b/s"),&$LOC("kb/s"),&$LOC("Mb/s"),&$LOC("Gb/s"));
            }
            $mul= 8;
        } else {
            if ($$rcfg{'options'}{'perminute'}{$router}) {
                @short = (&$LOC("B/min"),&$LOC("kB/min"),&$LOC("MB/min"),&$LOC("GB/min"));
            } elsif ($$rcfg{'options'}{'perhour'}{$router}) {
                @short = (&$LOC("B/h"),&$LOC("kB/h"),&$LOC("MB/h"),&$LOC("GB/h"));
            } else {
                @short = (&$LOC("B/s"),&$LOC("kB/s"),&$LOC("MB/s"),&$LOC("GB/s"));
            }
            $mul= 1;
        }
        if ($$rcfg{'shortlegend'}{$router}) {
            @short = ("$$rcfg{'shortlegend'}{$router}",
                      "k$$rcfg{'shortlegend'}{$router}",
                      "M$$rcfg{'shortlegend'}{$router}",
                      "G$$rcfg{'shortlegend'}{$router}");
        }
    }
    my $digits=length("".$number*$mul);
    my $divm=0;
    #
    #  while ($digits-$divm*3 > 4) { $divm++; }
    #  my $divnum = $number*$mul/10**($divm*3);
    my $divnum=$number*$mul*$$rcfg{'factor'}{$router};
    #  while ($divnum/$$rcfg{'kilo'}{$router} >= 10*$$rcfg{'kilo'}{$router} && $divnum<$#short) {
    while ($divnum >= 10*$$rcfg{'kilo'}{$router} && $divm<$#short) {
        $divm++;
        $divnum /= $$rcfg{'kilo'}{$router};
    }
    my $perc;
    if ($number == 0 || $maxbytes == 0) {
        $perc = 0;
    } else {
        $perc = 100/$maxbytes*$number;
    }
    if (defined $$rcfg{'options'}{'integer'}{$router}) {
        if ($$rcfg{'options'}{'nopercent'}{$router}) {
            return sprintf("%0.f %s",$divnum,$short[$divm]);
        } else {
            return sprintf("%0.f %s (%2.1f%%)",$divnum,$short[$divm],$perc);
        }
    } else {
        if (defined $$rcfg{'options'}{'nopercent'}{$router}) {
            return sprintf("%1.1f %s",$divnum,$short[$divm]); # Added: FvW
        } else {
            return sprintf("%1.1f %s (%2.1f%%)",$divnum,$short[$divm],$perc);
        }
        return sprintf("%1.1f %s (%2.1f%%)",$divnum,$short[$divm],$perc);
    }
}


sub writehtml {
    my($router, $cfg, $rcfg, $maxin, $maxout, $maxpercent,
       $avin, $avout, $avpercent, $cuin, $cuout, $cupercent, $uptime, $name, $LOC) = @_;
  
    my($VERSION,$Today,$peri);
  
    my($persec);

    if (defined $$rcfg{'options'}{'bits'}{$router}) {
        $persec = &$LOC("Bits");
    } else {
        $persec = &$LOC("Bytes");
    }

    #  Work out the Colour legend
    my($leg1, $leg2, $leg3, $leg4, $leg5);
    if ($$rcfg{'legend1'}{$router}) {
        $leg1 = $$rcfg{'legend1'}{$router};
    } else {
        $leg1 = &$LOC("Incoming Traffic in $persec per Second");
    }
    if ($$rcfg{'legend2'}{$router}) {
        $leg2 = $$rcfg{'legend2'}{$router};
    } else {
        $leg2 = &$LOC("Outgoing Traffic in $persec per Second");
    }
    if ($$rcfg{'legend3'}{$router}) {
        $leg3 = $$rcfg{'legend3'}{$router};
    } else {
        $leg3 = &$LOC("Maximal 5 Minute Incoming Traffic");
    }
    if ($$rcfg{'legend4'}{$router}) {
        $leg4 = $$rcfg{'legend4'}{$router};
    } else {
        $leg4 = &$LOC("Maximal 5 Minute Outgoing Traffic");
    }
    if ($$rcfg{'legend5'}{$router}) {
        $leg5 = $$rcfg{'legend5'}{$router};
    } else {
        $leg5 = "(($leg1)/($leg2))*100";
    }
    # Translate the color names
    $$rcfg{'col1'}{$router}=&$LOC($$rcfg{'col1'}{$router});
    $$rcfg{'col2'}{$router}=&$LOC($$rcfg{'col2'}{$router});
    $$rcfg{'col3'}{$router}=&$LOC($$rcfg{'col3'}{$router});
    $$rcfg{'col4'}{$router}=&$LOC($$rcfg{'col4'}{$router});
    $$rcfg{'col5'}{$router}=&$LOC($$rcfg{'col5'}{$router});

    my $dirrel = "../" x ($$rcfg{'directory_web'}{$router} =~ tr|/|/|);

    $Today=&$LOC(datestr(time));
    $VERSION = "2.9.4";
    open (HTML,">$$cfg{'htmldir'}$$rcfg{'directory'}{$router}$router.$$rcfg{'extension'}{$router}") || 
      do { warn ("WARNING: Writing $router.$$rcfg{'extension'}{$router}: $!");
      	   next };
    print HTML "<!-- Begin Head -->\n";
    print HTML '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">' . "\n";
    print HTML "<HTML>\n";
    my $interval =$$cfg{'interval'} ? $$cfg{'interval'} : 5;
    my $expiration = &expistr($interval);
    my $refresh =  $$cfg{'refresh'} ? $$cfg{'refresh'} : 300;
    my $namestring = &$LOC("the device");  
    print HTML <<"TEXT";    
<HEAD>
<TITLE>$$rcfg{'title'}{$router}</TITLE>
<META HTTP-EQUIV="Refresh" CONTENT="$refresh">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="$expiration">
TEXT

    print HTML 
      '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; '.&$LOC('charset=iso-8859-1')."\">\n";

    foreach $peri (qw(d w m y)) {
        print HTML <<"TEXT";
<!-- maxin $peri $$maxin{$peri}{$router} -->
<!-- maxout $peri $$maxout{$peri}{$router} -->
TEXT
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            print HTML <<"TEXT";
<!-- maxpercent $peri $$maxpercent{$peri}{$router} -->
TEXT
        }
        print HTML <<"TEXT";
<!-- avin $peri $$avin{$peri}{$router} -->
<!-- avout $peri $$avout{$peri}{$router} -->
TEXT
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            print HTML <<"TEXT";
<!-- avpercent $peri $$avpercent{$peri}{$router} -->
TEXT
        }
        print HTML <<"TEXT";
<!-- cuin $peri $$cuin{$peri}{$router} -->
<!-- cuout $peri $$cuout{$peri}{$router} -->
TEXT
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            print HTML <<"TEXT";
<!-- cupercent $peri $$cupercent{$peri}{$router} -->
TEXT
        }
    }
    if ($name ne '') {
        $namestring = "<B>'$name'</B>";
    }
    ;
    # allow for \n in addhead
    defined $$rcfg{addhead}{$router} or $$rcfg{addhead}{$router} = "";
    defined $$rcfg{backgc}{$router} or $$rcfg{backgc}{$router} = "";
    defined $$rcfg{pagetop}{$router} or $$rcfg{pagetop}{$router} = "";

    $$rcfg{addhead}{$router} =~ s/\\n/\n/g;

    print HTML <<"TEXT";    
$$rcfg{'addhead'}{$router}
</HEAD>
<BODY $$rcfg{'backgc'}{$router}>
$$rcfg{'pagetop'}{$router}<BR>
<HR>
TEXT

    if (defined $$rcfg{'timezone'}{$router}){    
    print HTML     
      &$LOC("The statistics were last updated <B>$Today $$rcfg{'timezone'}{$router}</B>");
    } else {
    print HTML     
      &$LOC("The statistics were last updated <B>$Today</B>");
    }
    if ($uptime && ! $$rcfg{options}{noinfo}{$router}) {
        print HTML
          ",<BR>\n".
        &$LOC("at which time $namestring had been up for <B>$uptime</B>.").
        "\n<!-- End Head -->";
    }

    my %sample= ('d' => "`Daily' Graph (".$interval.' Minute',
                 'w' => "`Weekly' Graph (30 Minute",
                 'm' => "`Monthly' Graph (2 Hour",
                 'y' => "`Yearly' Graph (1 Day");
  
    my %full = ('d' => 'day',
                'w' => 'week',
                'm' => 'month',
                'y' => 'year');
  
    my $InCo;
    $$rcfg{'rgb1'}{$router} = "" unless defined $$rcfg{'rgb1'}{$router};
    $$rcfg{'rgb2'}{$router} = "" unless defined $$rcfg{'rgb2'}{$router};
    $$rcfg{'rgb3'}{$router} = "" unless defined $$rcfg{'rgb3'}{$router};
    $$rcfg{'rgb4'}{$router} = "" unless defined $$rcfg{'rgb4'}{$router};
    $$rcfg{'rgb5'}{$router} = "" unless defined $$rcfg{'rgb5'}{$router};
    $$rcfg{'rgb6'}{$router} = "" unless defined $$rcfg{'rgb6'}{$router};

    if (exists $$rcfg{'legendi'}{$router}) {
        if ($$rcfg{'legendi'}{$router} ne "") {
            $InCo="<FONT COLOR=\"$$rcfg{'rgb1'}{$router}\">".
              "$$rcfg{'legendi'}{$router}</FONT>";
        }
    } else {
        $InCo="<FONT COLOR=\"$$rcfg{'rgb1'}{$router}\">".
          &$LOC("&nbsp;In:</FONT>");
    }
    my $OutCo;
    if (exists $$rcfg{'legendo'}{$router}) {
        if ($$rcfg{'legendo'}{$router} ne "") {
            $OutCo="<FONT COLOR=\"$$rcfg{'rgb2'}{$router}\">".
              "$$rcfg{'legendo'}{$router}</FONT>";
        }
    } else {
        $OutCo="<FONT COLOR=\"$$rcfg{'rgb2'}{$router}\">".
          &$LOC("&nbsp;Out:</FONT>");
    }
    my $PercentCo;
    if (defined $$rcfg{'legend5'}{$router}) {
        if ($$rcfg{'legend5'}{$router} ne "") {
            $PercentCo="<FONT COLOR=\"$$rcfg{'rgb5'}{$router}\">".
              "$$rcfg{'legend5'}{$router}</FONT>";
        }
    } else {
        $PercentCo="<FONT COLOR=\"$$rcfg{'rgb5'}{$router}\">".
          &$LOC("&nbsp;Percentage</FONT>");
    }
  
    foreach $peri (qw(d w m y)) {
        next if defined $$rcfg{'suppress'}{$router} and $$rcfg{'suppress'}{$router} =~/$peri/;
        my $gifw;
        if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
            $gifw=sprintf("%.0f",($$rcfg{'xsize'}{$router}*$$rcfg{'xscale'}{$router}+
                                  +100+30) *$$rcfg{'xzoom'}{$router});
        } else {
            $gifw=sprintf("%.0f",($$rcfg{'xsize'}{$router}*$$rcfg{'xscale'}{$router}
                                  +100) *$$rcfg{'xzoom'}{$router});
        }
        my $gifh=sprintf("%.0f",($$rcfg{'ysize'}{$router}*$$rcfg{'yscale'}{$router}+35)
                         *$$rcfg{'yzoom'}{$router});
                 
        # take the image directory away from the html directory to give us relative links


        print HTML "
<!-- Begin $sample{$peri} -->
<HR>
".&$LOC("<B>$sample{$peri}").&$LOC(" Average)</B><BR>")."
<IMG VSPACE=10 WIDTH=$gifw HEIGHT=$gifh ALIGN=TOP 
     SRC=\"$dirrel$$cfg{imagehtml}$$rcfg{directory_web}{$router}$router-$full{$peri}.${main::GRAPHFMT}\" ALT=\"$full{$peri}\">
 <TABLE CELLPADDING=0 CELLSPACING=0>
";
        my(@foo)=($rcfg,$LOC);
        print HTML "<TR>
  ".&$LOC("<TD ALIGN=right><SMALL>Max $InCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$maxin{$peri}{$router}, $$rcfg{'maxbytes1'}{$router}, $router, @foo)."
   </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Average $InCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$avin{$peri}{$router}, $$rcfg{'maxbytes1'}{$router}, $router, @foo)."
  </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Current $InCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$cuin{$peri}{$router}, $$rcfg{'maxbytes1'}{$router}, $router, @foo)."
  </SMALL></TD>
 </TR>
" if $InCo;
        print HTML "
 <TR>
  ".&$LOC("<TD ALIGN=right><SMALL>Max $OutCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$maxout{$peri}{$router}, $$rcfg{'maxbytes2'}{$router}, $router, @foo)."
  </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Average $OutCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$avout{$peri}{$router}, $$rcfg{'maxbytes2'}{$router}, $router, @foo)."
  </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Current $OutCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".&fmi($$cuout{$peri}{$router}, $$rcfg{'maxbytes2'}{$router}, $router, @foo)."
 </SMALL></TD>
 </TR> " if $OutCo;
        print HTML "
 <TR>
  ".&$LOC("<TD ALIGN=right><SMALL>Max $PercentCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".sprintf("%0.1f %%",$$maxpercent{$peri}{$router})."
  </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Average $PercentCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".sprintf("%0.1f %%",$$avpercent{$peri}{$router})."
  </SMALL></TD>
  <TD WIDTH=5></TD>
  ".&$LOC("<TD ALIGN=right><SMALL>Current $PercentCo</SMALL></TD>")."
  <TD ALIGN=right><SMALL>".sprintf("%0.1f %%",$$cupercent{$peri}{$router})."
 </SMALL></TD>
 </TR> " if ($$rcfg{'options'}{'dorelpercent'}{$router} && $PercentCo);
        print HTML "
</TABLE>
<!-- End $sample{$peri} -->\n";
    }
    print HTML "
<!-- Begin Legend -->
  <HR><BR>
  <TABLE WIDTH=500 BORDER=0 CELLPADDING=4 CELLSPACING=0>";
    print HTML "
   <TR><TD ALIGN=RIGHT><FONT SIZE=-1 COLOR=\"$$rcfg{'rgb1'}{$router}\">
      <B>$$rcfg{'col1'}{$router} ###</B></FONT></TD>
      <TD><FONT SIZE=-1>$leg1</FONT></TD></TR> " if $InCo;
    print HTML "
   <TR><TD ALIGN=RIGHT><FONT SIZE=-1 COLOR=\"$$rcfg{'rgb2'}{$router}\">
      <B>$$rcfg{'col2'}{$router} ###</B></FONT></TD>
      <TD><FONT SIZE=-1>$leg2</FONT></TD></TR> " if $OutCo;
  
    if ($$rcfg{'withpeak'}{$router}) {
        print HTML "
   <TR><TD ALIGN=RIGHT><FONT SIZE=-1 COLOR=\"$$rcfg{'rgb3'}{$router}\">
                        <B>$$rcfg{'col3'}{$router}###</B></FONT></TD>
       <TD><FONT SIZE=-1>$leg3</FONT></TD></TR> " if $InCo;
        print HTML "
   <TR><TD ALIGN=RIGHT><FONT SIZE=-1 COLOR=\"$$rcfg{'rgb4'}{$router}\">
                        <B>$$rcfg{'col4'}{$router}###</B></FONT></TD>
       <TD><FONT SIZE=-1>$leg4</FONT></TD></TR> "if $OutCo;
    }

    if ($$rcfg{'options'}{'dorelpercent'}{$router}) {
        print HTML "
   <TR><TD ALIGN=RIGHT><FONT SIZE=-1 COLOR=\"$$rcfg{'rgb5'}{$router}\">
                        <B>$$rcfg{'col5'}{$router}###</B></FONT></TD>
       <TD><FONT SIZE=-1>$leg5</FONT></TD></TR> ";
    }

    my $gifPath;

    if (defined $$cfg{icondir}) {
        $gifPath = $$cfg{icondir};
        #lets make sure there is a trailing path separator
        $gifPath =~ s|/*$|/|;
    } else {
	$gifPath = "$dirrel$$cfg{imagehtml}";
    }

    print HTML<<TEXT;
</TABLE><BR><HR><BR>
<!-- End Legend -->
<!-- Begin MRTG Block -->
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR>
    <TD WIDTH=63><A
    HREF="http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="${gifPath}mrtg-l.${main::GRAPHFMT}" WIDTH=63 HEIGHT=25 ALT="MRTG"></A></TD>
    <TD WIDTH=25><A
    HREF="http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="${gifPath}mrtg-m.${main::GRAPHFMT}" WIDTH=25 HEIGHT=25 ALT=""></A></TD>
    <TD WIDTH=388><A
    HREF="http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="${gifPath}mrtg-r.${main::GRAPHFMT}" WIDTH=388 HEIGHT=25
    ALT="Multi Router Traffic Grapher"></A></TD>
  </TR>
</TABLE>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR VALIGN=top>
  <TD WIDTH=88 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
TEXT

    print HTML &$LOC("version")." $VERSION</FONT></TD>\n";
    print HTML<<TEXT;
  <TD WIDTH=388 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
  <A HREF="http://ee-staff.ethz.ch/~oetiker/">Tobias Oetiker</A>
  <A HREF="mailto:oetiker\@ee.ethz.ch">&lt;oetiker\@ee.ethz.ch&gt;</A> 
TEXT
    print HTML &$LOC("and");
    print HTML<<TEXT;
  &nbsp;
  <A HREF="http://www.bungi.com/">Dave&nbsp;Rand</A>&nbsp;
  <A HREF="mailto:dlr\@bungi.com">&lt;dlr\@bungi.com&gt;</A></FONT>
  </TD>
</TR>
</TABLE>
TEXT

    # We don't need this any more.
    undef $gifPath;

    if ($MRTG_lib::OS eq 'VMS') {
        print HTML 
          " <HR NOSHADE>
".&$LOC("Ported to OpenVMS Alpha by").".
  <NOBR><A HREF=\"http://www.cerberus.ch/\">Werner Berger</A>
  <A href=\"mailto:werner.berger\@cch.cerberus.ch\">
  &lt;werner.berger\@cch.cerberus.ch&gt;</A></NOBR>
";

    }
    if ($MRTG_lib::OS eq 'NT') {
        print HTML 
          "  <HR NOSHADE>
  ".&$LOC("Ported to WindowsNT by")."
  <NOBR><A HREF=\"http://www.testlab.orst.edu/\">Stuart Schneider</A>
  <A HREF=\"mailto:schneis\@testlab.orst.edu\">
  &lt;schneis\@testlab.orst.edu&gt;</A></NOBR>
";
    }
    if ( 
        $$cfg{'language'} && 
        defined($lang2tran::LOCALE{"\L$$cfg{'language'}\E"}) &&
        ($LOC != $lang2tran::LOCALE{"default"})
       ) {
        if (defined($credits::LOCALE{"\L$$cfg{'language'}\E"})) {
            print HTML $credits::LOCALE{"\L$$cfg{'language'}\E"};
        } else {
            print HTML $credits::LOCALE{'default'};
        }
        ;
    }

    print HTML "<!-- End MRTG Block -->\n";

    print HTML $$rcfg{'pagefoot'}{$router} if defined $$rcfg{'pagefoot'}{$router};
    print HTML <<TEXT;
</BODY>
</HTML>

TEXT
    close HTML;

    if ($$cfg{'writeexpires'} =~ /^y/i) {
        open(HTMLG, ">$$cfg{'htmldir'}$$rcfg{'directory'}{$router}$router.".
	     "$$rcfg{'extension'}{$router}.meta") ||
	       do {
		   warn "WARNING: Writing $$cfg{'htmldir'}$$rcfg{'directory'}{$router}$router.".
		     "$$rcfg{'extension'}{$router}.meta: $!\n";
		   next
	       };

        print HTMLG "Expires: $expiration\n";
        close(HTMLG);
    }
}


sub printusage {
    print <<USAGEDESC;
Usage: mrtg <config-file>

mrtg is the Multi Router Traffic Grapher.

If you want to know more about this tool, you might want
to read the docs. They came together with mrtg! 

Home: http://ee-staff.ethz.ch/~oetiker/webtools/mrtg/mrtg.html

USAGEDESC
    exit(1);
}


sub lockit {
    my ($lockfile,$templock) = @_;
    if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
        # too sad NT and VMS can't do links we'll do the diletants lock
        if (-e $lockfile && not unlink $lockfile) {
            my($lockage) = time()-(stat($lockfile))[9];
            die "ERROR: I guess another mrtg is running. A lockfile ($lockfile)\n".
                 "       aged $lockage seconds is hanging around and I can't remove\n".
                 "       it because another process is still using it.";
        }
      
        open (LOCK, ">$lockfile") or 
          die "ERROR: Creating lockfile $lockfile: $!\n";
        print LOCK "$$\n";
        close LOCK;
        open (LOCK, "<$lockfile") or 
          die "ERROR: Reading lockfile $lockfile for owner check: $!\n";
        my($read)=<LOCK>;
        chomp($read);
        die "ERROR: Someone else just got the lockfile $lockfile\n" 
          unless  $$ == $read;
    } else {
        # now, lets do it the UNIX way ... Daves work ...
        open(LOCK,">$templock") || die "ERROR: Creating templock $templock: $!";
        $main::Cleanfile = $templock;
        if (!link($templock,$lockfile)) { # Lock file exists - deal with it.
            $main::Cleanfile2 = $lockfile;
            my($nlink,$lockage) = (stat($lockfile))[3,9]; 
            $lockage = time() - $lockage;
            if ($nlink < 2 || $lockage > 30*60) { #lockfile is alone and old
                unlink($lockfile) 
                  || do{ unlink $templock; 
                         die "ERROR: Can't unlink stale lockfile ($lockfile). Permissions?\n"};
                link($templock,$lockfile) 
                  || do{ unlink $templock; 
                         die "ERROR: Can't create lockfile ($lockfile).\n".
                           "Permission problem or another mrtg locking succesfully?\n"};
            } else {
                unlink $templock;
                die  "ERROR: I guess another mrtg is running. A lockfile ($lockfile) aged\n".
                     "$lockage seconds is hanging around. If you are sure that no other mrtg\n".
                     "is running you can remove the lockfile\n";
          
            }
        
        }
    }
}

sub threshcheck {
    # threshold checking ... by Tom Muggli     
    my ($cfg,$rcfg,$cfgfile,$router,$cuin,$cuout) = @_;
    my (@threshinexec, @threshoutexec, $threshinval, 
        $threshoutval, $threshfile, @threshtmp);
    @threshinexec = ();
    @threshoutexec = ();
    $threshinval = 0 + $$cuin{'d'}{$router};
    $threshoutval = 0 + $$cuout{'d'}{$router};
    if (defined $$cfg{'threshdir'}){
        ensureSL(\$$cfg{'threshdir'});
        $threshfile = $$cfg{'threshdir'};
    };
      
    @threshtmp = split(/\Q$MRTG_lib::SL\E/, $cfgfile);
    $threshfile .= "$threshtmp[$#threshtmp].$router";
    if (defined $$rcfg{'threshdesc'}{$router}) {
        $ENV{THRESH_DESC}=$$rcfg{'threshdesc'}{$router};
    } else {
        delete $ENV{THRESH_DESC};
    }
    if ($$rcfg{'threshmini'}{$router} && 
        $$rcfg{'threshmini'}{$router} > $threshinval) {
        @threshinexec = ("$$rcfg{'threshprogi'}{$router}", 
                         "$router", "$$rcfg{'threshmini'}{$router}", 
                         "$threshinval");
    }
    if ($$rcfg{'threshmaxi'}{$router} && 
        $$rcfg{'threshmaxi'}{$router} < $threshinval) {
        @threshinexec = ("$$rcfg{'threshprogi'}{$router}", 
                         "$router", "$$rcfg{'threshmaxi'}{$router}", 
                         "$threshinval");
    }
    if (scalar(@threshinexec) > 0) {
        if (defined $$cfg{'threshdir'} && 
            $$rcfg{'threshprogoki'}{$router} && -d $$cfg{'threshdir'}) {
            # Create a file to indicate a threshold problem for the next running.
            open (THRESHTOUCH, ">$threshfile.I") or warn "WARNING: Creating $threshfile.I: $!\n";
            close (THRESHTOUCH);
        }  
        if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
            open (THRESHIN, join (" ", @threshinexec)."|");
        } else {
            open (THRESHIN, "-|") || exec @threshinexec;
        }  
        close (THRESHIN);
    } else {
        if ($$cfg{'threshdir'} && 
            $$rcfg{'threshprogoki'}{$router} && -e "$threshfile.I") {
            # If a previous running broke a threshold, but now we're inside.
            @threshinexec = ("$$rcfg{'threshprogoki'}{$router}", 
                             "$router", "$threshinval");

            if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
                open (THRESHIN, join (" ", @threshinexec)."|");
            } else { 
                open (THRESHIN, "-|") || exec @threshinexec;
            }
            close (THRESHIN);
            unlink("$threshfile.I");
        }  
    }  
      
    if ($$rcfg{'threshmino'}{$router} && 
        $$rcfg{'threshmino'}{$router} > $threshoutval) {
        @threshoutexec = ("$$rcfg{'threshprogo'}{$router}", 
                          "$router", "$$rcfg{'threshmino'}{$router}", 
                          "$threshoutval");
    }
    if ($$rcfg{'threshmaxo'}{$router} && 
        $$rcfg{'threshmaxo'}{$router} < $threshoutval) {
        @threshoutexec = ("$$rcfg{'threshprogo'}{$router}", 
                          "$router", "$$rcfg{'threshmaxo'}{$router}", 
                          "$threshoutval");
    }
    if (scalar(@threshoutexec) > 0) {
        if ($$cfg{'threshdir'} && 
            $$rcfg{'threshprogoko'}{$router} && -d $$cfg{'threshdir'}) {
            # Create a file to indicate a threshold problem for the next running.
            open (THRESHTOUCH, ">$threshfile.O");
            close (THRESHTOUCH);
        }  
        if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
            open (THRESHOUT, join (" ", @threshoutexec)."|");
        } else {
            open (THRESHOUT, "-|") || exec @threshoutexec;
        }  
        close (THRESHOUT);
    } else {
        if ($$cfg{'threshdir'} && 
            $$rcfg{'threshprogoko'}{$router} && -e "$threshfile.O") {
            # If a previous running broke a threshold, but now we're inside.
            @threshoutexec = ("$$rcfg{'threshprogoko'}{$router}", 
                              "$router", "$threshoutval");

            if ($MRTG_lib::OS eq 'VMS' || $MRTG_lib::OS eq 'NT') {
                open (THRESHIN, join (" ", @threshoutexec)."|");
            } else {
                open (THRESHIN, "-|") || exec @threshoutexec;
            }
            close (THRESHIN);
            unlink("$threshfile.O");
        }  
    }  
    #  end of threshold checking ...
}

sub getexternal ($) {
    my $command = shift;
    my $in=-1;
    my $out=-1;
    my $uptime;
    my $name;

    open (EXTERNAL , $command."|")
	|| warn "WARNING: Running '$command': $!\n";

    warn "WARNING: Could not get any data from external command ".
	"'".$command.
	    "'\nMaybe the external command did not even start. ($!)\n\n" if eof EXTERNAL;

    chomp( $in=<EXTERNAL>) unless eof EXTERNAL;
    chomp( $out=<EXTERNAL>) unless eof EXTERNAL;
    chomp( $uptime=<EXTERNAL>) unless eof EXTERNAL;
    chomp( $name=<EXTERNAL>) unless eof EXTERNAL;

    close EXTERNAL;

    # strip returned date
    $in  =~ s/^\s*(.*?)\s*/$1/;
    $out  =~ s/^\s*(.*?)\s*/$1/;
    $uptime  =~ s/^\s*(.*?)\s*/$1/;
    $name  =~ s/^\s*(.*?)\s*/$1/;

    # do we have numbers in the external programs answer ?
    if ( $in != $in * 1 ) {
	warn "WARNING: Problem with External get '$command':\n".
	    "   Expected an Number for 'in' but got '$in'\n\n";
	$in = $in * 1;
    }

    if ( $out != $out * 1 ) {
	warn "WARNING: Problem with Externale get '$command':\n".
	    "   Expected a Number for 'out' but got '$out'\n\n";
	$out = $out * 1;
    }
    return ($in,$out,time,$uptime,$name);
}

sub getsnmparg ($$$){
    my $confcache = shift;
    my $target = shift;
    my $cfg = shift;
    my $retry = 0;
  RETRY:
    my @ifnum = ();
    my @OID = ();
    # Find apropriate Interface to poll from
    for my $i (0..1) {
	if ($$target{IfSel}[$i] eq 'If') {
	    $ifnum[$i] = ".".$$target{Key}[$i];
	    debug('snpo',"simple If: $ifnum[$i]");
	} elsif($$target{IfSel}[$i] eq 'None') {
            $ifnum[$i] = "";
        } else {
	    if (not defined $$confcache{"$$target{Community}\@$$target{Host}"}{$$target{IfSel}[$i]}{$$target{Key}[$i]}) {
		debug('snpo',"($i) Populate ConfCache for $$target{Host}");
		populateconfcache($confcache,"$$target{Community}\@$$target{Host}",1);
	    }
	    if (not defined $$confcache{"$$target{Community}\@$$target{Host}"}{$$target{IfSel}[$i]}{$$target{Key}[$i]}) {
		warn "WARNING: Could not match host:'$$target{Community}\@$$target{Host}' ref:'$$target{IfSel}[$i]' key:'$$target{Key}[$i]'\n";
		return undef;
	    } else {
		$ifnum[$i] = ".".$$confcache{"$$target{Community}\@$$target{Host}"}{$$target{IfSel}[$i]}{$$target{Key}[$i]};
		debug('snpo',"($i) Confcache Match $$target{Key}[$i] -> $ifnum[$i]");
	    }
	}
	if ($ifnum[$i] !~ /^$|^\.\d+$/) {
	    warn "WARNING: Can not determine".
	      " ifNumber for $$target{Community}\@$$target{Host} \tref: '$$target{IfSel}[$i]' \tkey: '$$target{Key}[$i]'\n";
	    return undef;
	}
    }
    for my $i (0..1) {
	# add ifget methodes call for a cross check;
	for ($$target{IfSel}[$i]) {
	    /^Eth$/ && do {
		push @OID, "ifPhysAddress".$ifnum[$i]; last
	    };
	    /^Ip$/ && do {
		push @OID, "ipAdEntIfIndex".".".$$target{Key}[$i];last
	    };
	    /^Descr$/ && do {
		push @OID, "ifDescr".$ifnum[$i]; last
	    };
	    /^Type$/ && do {
		push @OID, "ifType".$ifnum[$i]; last
	    };
	    /^Name$/ && do {
		push @OID, "ifName".$ifnum[$i]; last
	    };
	}
	push @OID ,$$target{OID}[$i].$ifnum[$i];
    }
    # we also want to know uptime and system name unless we are
    # looking at a squid cache or the user did a nomib2
    if ( $OID[0] !~ /^cache.+$/ and
	 $OID[0] !~ /^\Q1.3.6.1.4.1.3495.1\E/ and 
	 not defined $$cfg{nomib2} and $$cfg{logformat} ne 'rrdtool' ) {
	 push @OID, qw(sysUptime sysName)
    }
    # pull that data
    debug('snpo',"SNMPGet from $$target{Community}\@$$target{Host}$$target{SnmpOpt} -- ".(join ",", @OID));
    my @ret = snmpget($$target{Community}.'@'.$$target{Host}.$$target{SnmpOpt},@OID);
    debug('snpo',"SNMPfound -- ".(join ", ", map {"'$_'"}  @ret));
    my $time = time;
    my @final;
    # lets do some reality check
    for my $i (0..1) {
	# some ifget methodes call for a cross check;
	for ($$target{IfSel}[$i]) {
	    /^Eth$/ && do {
		my $bin = shift @ret;
		my $eth = unpack 'H*', $bin;
		my @eth;
		while ($eth =~ s/^..//){
		    push @eth, $&;
		}
		my $phys=join '-', @eth;
		if ($phys ne $$target{Key}[$i]) {
		    debug('snpo', "($i) eth if crosscheck got $phys expected $$target{Key}[$i]");
		    if (not $retry) {
			$retry=1;
			# remove broken entry
			$$confcache{$$target{Community}.'@'.$$target{Host}}{$$target{IfSel}[$i]}{$$target{Key}[$i]} = undef;
			debug('snpo',"($i) goto RETRY force if cache repopulation");
			goto RETRY;
		    } else {
			warn "WARNING: could not match&get".
			  " $$target{Host}/$$target{OID}[$i] for Eth $$target{Key}[$i]\n";
			return undef;
		    }
		};
		debug ('snpo',"($i) Eth crosscheck OK")
	    };
	    /^Ip$/ && do {
		my $if = shift @ret;
		if ($ifnum[$i] ne '.'.$if) {
		    debug('snpo', "($i) IP if crosscheck got .$if expected $ifnum[$i]");
		    if (not $retry) {
			$retry=1;
			# remove broken entry
			$$confcache{$$target{Community}.'@'.$$target{Host}}{$$target{IfSel}[$i]}{$$target{Key}[$i]} = undef;
			debug('snpo',"($i) goto RETRY force if cache repopulation");
			goto RETRY;
		    } else {
			warn "WARNING: could not match&get".
			  " $$target{Host}/$$target{OID}[$i] for IP $$target{Key}[$i]\n";
			return undef;
		    }
		}
		debug ('snpo',"($i) IP crosscheck OK")
	    };
	    /^(Descr|Name|Type)$/ && do {
		my $descr = shift @ret;
		if ($descr ne $$target{Key}[$i]) {
		    debug('snpo', "($i) $_ if crosscheck got $descr expected $$target{Key}[$i]");
		    if (not $retry) {
			$retry=1;
			# remove broken entry
			$$confcache{$$target{Community}.'@'.$$target{Host}}{$$target{IfSel}[$i]}{$$target{Key}[$i]} = undef;
			debug('snpo',"($i) goto RETRY force if cache repopulation");
			goto RETRY;
		    } else {
			warn "WARNING: could not match&get".
			  " $$target{Host}/$$target{OID}[$i] for $_ '$$target{Key}[$i]'\n";
			return undef;
		    }
		}
		debug ('snpo',"($i) $_ crosscheck OK")
	    };
	}
	if ($$target{OID}[$i] =~ /if(Admin|Oper)Hack/) {
	    push @final, (shift @ret == 1) ? 1:0;
	} else {
	    push @final, shift @ret;
	}
    }
    # return the data we found
    return @final,$time, @ret;
}


# read target function ...
sub readtargets ($$$) {
    my ($confcache,$target,$cfg) = @_;
    my $forks = $$cfg{forks};
    my $trgnum = $#{$target}+1;
    if (defined $forks and $forks > 1  and $trgnum > 1){
        $forks = $trgnum if $forks > $trgnum;
        my $split = int($trgnum / $forks) + 1;       
	my @hand;
	# get them forks to work ... 
	for (my $i = 0; $i < $forks;$i++) {
	    local *D;
            my $sleep_count=0;
            my $pid;
            do {
               $pid = open(D, "-|");
                unless (defined $pid) {
                    warn "WARNING cannot fork: $!\n";
                    die "ERROR bailing out after 6 faild forkattempts"
                         if $sleep_count++ > 6;
                    sleep 10;
                }
            } until defined $pid;
	    if ($pid) { # parent
     		$hand[$i] = *D; # funky file handle magic ... 
		debug ('fork',"Parent $$ after fork of child $i");
	    } else {  # child
		debug ('fork',"Child $i ($$) after fork");
		my $res = "";
		for (my $ii = $i * $split; 
		     $ii < ($i+1) * $split and $ii < $trgnum;
		     $ii++){
		    my $targ = $$target[$ii];
		    my @res;
		    if ($$targ{Methode} eq 'EXEC') {
			@res = getexternal($$targ{Command});
		    } else { # parent
			@res = getsnmparg($confcache,$targ,$cfg);
		    }
		    for (my $iii=0;$iii<5;$iii++){
			if (defined $res[$iii]){
                            $res .= "$res[$iii]\n";
			} else {
                            $res .= "##UNDEF##\n";
			}
		    }
		}
		debug ('fork',"Child $i ($$) waiting to deliver");
		print $res; # we only talk after the work has been done to
                  	    # otherwhise we might get blocked 
                # return updated hosts from confcache
                writeconfcache($confcache,'&STDOUT')
                        if defined $$confcache{___updated};
		exit 0;
	    }
	    
	}
	# happy reaping ... 
	for (my $i = 0; $i < $forks;$i++) {  
	    debug ('fork',"Parent reading child $i");
	    my $h = $hand[$i];
	    for (my $ii = $i * $split; 
		 $ii < ($i+1) * $split and $ii < $trgnum;
		 $ii++){ 
		my $targ = $$target[$ii];
		my @res;
		for (0..4){
		    my $line = <$h>; # must be a simple scalar here else it wont work
		    die "ERROR: fork $i has died ahead of time ...\n" if not defined $line;
		    chomp $line;
#                    debug ('fork',"reading for $ii $line");
		    $line = undef if $line eq "##UNDEF##";                
		    push @res,$line;
		}
		($$targ{_IN_},
		 $$targ{_OUT_},
		 $$targ{_TIME_},
		 $$targ{_UPTIME_},
		 $$targ{_NAME_}) = @res;
            }     
            # feed confcache entries
            my $lasthost ="";
            while (<$h>){
                chomp;
                my ($host,$method,$key,$value) = split (/\t/, $_);
                if ($host ne $lasthost){
        	     debug ('fork',"start undef for $host");
                     $$confcache{$host} = undef;
        	     debug ('fork',"end undef for $host");
                }
                $lasthost = $host;
                storeincache($confcache,$host,$method,$key,$value);
             }
             close $h;
        }
	            
    } else {
	foreach my $targ (@$target) {
	    if ($$targ{Methode} eq 'EXEC') {
		debug('snpo', "run external $$targ{Command}");
		($$targ{_IN_},
		 $$targ{_OUT_},
		 $$targ{_TIME_},
		 $$targ{_UPTIME_},
		 $$targ{_NAME_}) = getexternal($$targ{Command});
	    } elsif ($$targ{Methode} eq 'SNMP') {
		debug('snpo', "run snmpget from $$targ{OID}[0]&$$targ{OID}[1]:$$targ{Community}\@$$targ{Host}");
		($$targ{_IN_},
		 $$targ{_OUT_},
		 $$targ{_TIME_},
		 $$targ{_UPTIME_},
		 $$targ{_NAME_}) = getsnmparg($confcache,$targ,$cfg);
	    }	    
	}
    }
        
}
