#!/usr/bin/perl

use strict;

my $l = `/usr/bin/uptime`;
$l =~ m/load average:\W+(\d\d*\.\d\d)\W+(\d\d*\.\d\d)\W+(\d\d*\.\d\d)/;

my $time1 = $1;
my $time2 = $2;

$time1 *= 100.0;
$time2 *= 100.0;

print STDOUT (int($time1)."\n".
              int($time2)."\n".
              localtime() . "\n" .
              "uptime\n"
             );

