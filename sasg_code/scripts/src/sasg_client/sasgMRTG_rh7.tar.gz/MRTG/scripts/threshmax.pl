#!/usr/bin/perl

($thresh,$cur) = @ARGV[1,2];
open MAIL,"|/usr/bin/mail -s IHS_overload blacksmith\@us.ibm.com"
  or die "mail $!";
print MAIL "MAX: $thresh\nCUR: $cur\n\n";

open ESTAB,"netstat -an|" or die "netstat -an: $!";
while (<ESTAB>)
{
  next unless /^tcp4.*ESTAB/;         # only ESTABLISHED tcp connections
  ($local,$remote) = (split)[3,4];
  next unless $local =~ /\.80$/;      # only connection on port 80

  $remote =~ s/\.\d+$//;              # strip remote port number
  $remotes{$remote}++;                # count connnections from each ip
}
close ESTAB;

print MAIL "Connections by ip address:\n";
for (sort { $remotes{$b} <=> $remotes{$a} } keys %remotes)
{
  print MAIL "$_ => $remotes{$_}\n";
}

close MAIL;

