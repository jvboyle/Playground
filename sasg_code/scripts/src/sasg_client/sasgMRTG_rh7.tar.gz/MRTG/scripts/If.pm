package If;
use Exporter;

use strict;
use Cell;
use Cfg;

use vars qw(@ISA @EXPORT);

@ISA = qw(Exporter);
@EXPORT = qw(ifs);

my $host = `hostname`;
my @if = `/sbin/ifconfig -a`;
my $state = 1;
my ($if,$ip);
my (@cells,@confs);

($host = `hostname`) =~ s/^\s+|\s+$//g;

sub ifs
{
  my %ifs = ();
  for (@if)
  {
    my @tokens = split;
    if ($state == 1)
    {
      next unless $tokens[0] =~ /^(...)\:$/;
#     next unless $1 =~ /^en/ or $1 =~ /^tr/;
      $if = $1;
      $state = 2;
    }
    elsif ($state == 2)
    {
      if (/^\s+inet/)
      {
         $ip = $tokens[1];
         my $max;
         $max = 2000000 if $if =~ /^tr/;
         $max = 125000000 if $if =~ /^hsi/;
#        $max = 125000000 if $if =~ /^et/;
         $ifs{$if} =
                 cell(Key => $if, Title => "Traffic for $ip -- $host");
         cfg(KEY => $if, TITLE => "Traffic for $ip -- $host",
             MAX => $max, OPTIONS => "bits",
             YLEG => "bits per second", SHORT => "b/s",
             IN => "In", OUT => "Out",
             TARGET =>
                 '`/sasg/MRTG/scripts/netutil.pl '.$if.'`'
            );
      }
      $state = 1;
    }
  }
  return %ifs;
}

1;
