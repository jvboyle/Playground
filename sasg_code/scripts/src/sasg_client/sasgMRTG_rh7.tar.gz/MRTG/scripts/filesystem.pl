#!/usr/bin/perl

$fs = shift;
($key = $fs) =~ s!/!.!g;
$key =~ s/^\.+//g;
$key = "root" unless $key;

@df = `df -k`;
shift @df;

for (@df)
{
  s/\s+$//g;
  next unless m!$fs$!;
  ($max,$free) = (split)[1,2];
  $used = $max-$free;
}

print "$used\n$max\n";
print scalar(localtime),"\n";
print "$key\n";
