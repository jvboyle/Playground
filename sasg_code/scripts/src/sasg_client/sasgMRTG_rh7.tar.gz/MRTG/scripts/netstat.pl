#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  for (`netstat -ni|head -100`)
  {
    $dups{$_}++;
  }

  %dups = (reverse((%dups)));

  $x = 0;
  for (sort keys %dups)
  {
    $x = 4 if $_ > 20;
  }

  print "$x\n$x\n";
  print localtime()."\n";
  print "HTTP Sessions\n";
};

if ($@ =~ /timeout/) { exit };
