package Static;
use Exporter;

use strict;
use Cell;
use Cfg;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);
@EXPORT = qw(static);

my $hostname = `hostname`;

sub static
{
  my @static = ();
  my $limit;

  my @ifs;
  my $if;

  if (open IF, "<", "/proc/net/dev") {
     my $header = <IF>;
     while (<IF>) {
        if (/^\s*(\S+)\:/) {
           push @ifs,$1;
        }
     }

     for $if (@ifs) {
        next if $if =~ /^lo/;
        push @static,($if => Cell::cell(Key => "$if", Title => "Traffic for $if on $hostname"));
        Cfg::cfg(KEY => "$if", TITLE => "Traffic for $if on $hostname", MAX => 125000000,
            OPTIONS => "bits,nobanner", IN => "In", OUT => "Out",
            YLEG => "bits per second", SHORT => "b/s",
            TARGET => "`/sasg/MRTG/scripts/network.pl $if`"
        );
     }
  }

  push @static,(cpuperc => cell(Key => "cpuperc", Title => "%CPU"));
  cfg(KEY => "cpuperc", TITLE => "vmstat %CPU", MAX => 100,
      OPTIONS => "gauge,nobanner", IN => "Wait", OUT => "Not Idle",
      YLEG => "%CPU", SHORT => "%CPU",
      TARGET => '`/sasg/MRTG/scripts/cpu.pl`'
     );

  push @static,(load => cell(Key => "load", Title => "System Load Average"));
  cfg(KEY => "load", TITLE => "System Load Average", MAX => 2000,
      OPTIONS => "gauge,nobanner", IN => "Last 5", OUT => "Last 10",
      YLEG => "Process Times", SHORT => "Proc",
      TARGET => '`/sasg/MRTG/scripts/load.pl`'
     );

  my $mem = `/usr/bin/free -b |grep "^Mem"`;
  my $max = (split(/\s+/,$mem))[1];
  push @static,(mem => cell(Key => "mem", Title => "Memory"));
  cfg(KEY => "mem", TITLE => "Memory", MAX => $max,
      OPTIONS => "gauge,nobanner", IN => "Used", OUT => "Total",
      YLEG => "Memory", SHORT => "bytes",
      TARGET => '`/sasg/MRTG/scripts/mem.pl`'
     );

  my $mem = `/usr/bin/free -b|grep "^Swap"`;
  my $max = (split(/\s+/,$mem))[1];
  push @static,(swap => cell(Key => "swap", Title => "Swap Space"));
  cfg(KEY => "swap", TITLE => "Swap Space", MAX => $max,
      OPTIONS => "gauge,nobanner", IN => "Used", OUT => "Total",
      YLEG => "Swap Space", SHORT => "bytes",
      TARGET => '`/sasg/MRTG/scripts/swap.pl`'
     );

  return @static;
}
