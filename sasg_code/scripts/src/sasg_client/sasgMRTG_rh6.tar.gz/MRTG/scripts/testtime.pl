#!/usr/bin/perl
#!/usr/custom/perl-5.8.0/bin/perl

use strict;
use Fcntl qw(:flock);

open LOCK,">/sasg/MRTG/lock";
exit unless flock(LOCK,LOCK_EX|LOCK_NB);

my $l = `/usr/bin/uptime`;
$l =~ m/load average:\W+(\d\d*\.\d\d)\W+(\d\d*\.\d\d)\W+(\d\d*\.\d\d)/;

my $time1 = int $1;
my $time2 = int $2;

print STDOUT ("$time1\n".
              "$time2\n".
              localtime() . "\n" .
              "uptime\n"
             );

