#!/usr/bin/perl

$ENV{TERM} = 'vt100';

($prod) = $ARGV[0] || 'en0';

%prod = ( tr => tokstat, en => entstat, fi => fddistat );

$cmd = $prod{substr($prod,0,2)};

open MON,"$cmd $prod|";

while (<MON>)
{
   next unless /^Bytes/;
   s/\s+$//g;
   /^\D+(\d+)\D+(\d+)$/;
   push @ints, "$prod $2 $1";
}
close MON;

if (grep { $_ eq $prod } "en0","en1","lo0","tr0","tr1")
{
  ($int) = grep { /$prod/ } @ints;
  ($name,$in,$out) = split(/\s+/,$int);
  print $in,"\n";
  print $out,"\n";
  print localtime()."\n";
  print "$name\n";
}
else
{
  print "$_\n" for @ints;
}

