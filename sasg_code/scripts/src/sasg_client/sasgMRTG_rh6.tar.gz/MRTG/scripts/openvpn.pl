#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  @result = `ps -ef|grep /usr/sbin/openvpn|grep -v grep`;

  if (@result) {
      $x = 100;
      $y = 0;
  } else {
      $x = 0;
      $y = 100;
  }

  print "$y\n$x\n";
  print "NA\n";
  print "OpenVPN Status\n";
};

if ($@ =~ /timeout/) { exit };
