#!/usr/bin/perl

use strict;


my %hash;
my $DEBUG;

die "usage  $0 var1 var2 \n\twhere var is name of value from vmstat" if (@ARGV != 2 );
my $want1 = $ARGV[0];
my $want2 = $ARGV[1];

my @vmstat  = `vmstat 60 2`;
my $vm_nam_line  = @vmstat[($#vmstat - 2)];
my $vm_num_line  = @vmstat[$#vmstat];

my @names   = split (/\W+/, $vm_nam_line);
my @numbers = split (/\W+/, $vm_num_line);

print STDOUT ($vm_nam_line . "\n#\n ". $vm_num_line. "\n")   if $DEBUG;
print STDOUT (scalar (@names) . " vs " . scalar (@numbers))  if $DEBUG;


if ( scalar (@names) ==  scalar (@numbers) ) {
    for (my $i=0; $i < $#names; $i++) {

	print STDOUT (" hash{ " . $names[$i] . " } = " . $numbers[$i] ."\n")  if $DEBUG;
	$hash{$names[$i]} = $numbers[$i];
	$hash{$names[$i]} = $numbers[$i];
    }
}

if ($DEBUG) {
    foreach my $val (keys %hash) {
        print STDOUT (" $val = " . $hash{$val} . "\n");
    }
}

print STDOUT (   $hash{$want1} . "\n" . 
                 $hash{$want2} . "\n" . 
                 localtime()   . "\n" .
		 'vmstat info'  . "\n"
             );

