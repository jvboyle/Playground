#!/usr/custom/perl-5.8.0/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  for (`lsps -s`)
  {
    s/^\s+|\s+$//;
    next unless /^\d+/;
    ($x,$y) = /^(\d+)MB\s+(\d+)/;
  }

  $y = int ($x/100)*$y;

  print "$y\n$x\n";
  print localtime()."\n";
  print "Paging Space\n";
};

if ($@ =~ /timeout/) { exit };
