#!/usr/bin/perl

sleep 20;

my @vmstat  = `vmstat 30 2`;

my ($x,$y) = (split(/\s+/,$vmstat[-1]))[-3,-2];

$x = 100-$x;

print "$y\n$x\n";

print scalar(localtime()),"\n";
print "vmstat info\n"


