package Cfg;
use Exporter;

use strict;
use vars qw(@ISA @EXPORT);

@ISA = qw(Exporter);
@EXPORT = qw(cfg);

my $host = `hostname`;
$host = s/\.[^.]+//g;
my ($workdir,$threshdir,$confdir);

$workdir = "/sasg/MRTG/stats";
$threshdir = "/sasg/MRTG/data-in";
$confdir = "/sasg/MRTG/conf";

mkdir "$workdir", 0755  unless -e "$workdir";
mkdir "$confdir", 0755  unless -e "$confdir";

my @DATA = <DATA>;

sub cfg
{
   my @conf = ();
   my @data = @DATA;
   my %args = @_;
   $args{INLONG} ||= $args{IN};
   $args{OUTLONG} ||= $args{OUT};
   for (@data)
   {
      next if /^Thresh/ and not $args{Thresh};
      s/%WORKDIR%/$workdir/g;
      s/%THRESHDIR%/$threshdir/g;
      for my $key (keys %args)
      {
        s/\%$key\%/$args{$key}/g;
      }
      push @conf,$_;
   }
   if ($args{COLOURS}) {
      push @conf,"Colours[$args{KEY}]: $args{COLOURS}\n"
   }
   open CONF,">$confdir/$args{KEY}.cfg"
     or die "Can't write $confdir/$args{KEY}.cfg";
   flock(CONF,2);
   print CONF for @conf;
   close CONF;
}

1;


__DATA__
WorkDir: %WORKDIR%
ThreshDir: %THRESHDIR%

WriteExpires: Yes

Language: english

MaxBytes[%KEY%]: %MAX%
Target[%KEY%]: %TARGET%
Title[%KEY%]: %TITLE%
PageTop[%KEY%]: <h1>%TITLE% </h1>
Options[%KEY%]: %OPTIONS%
YLegend[%KEY%]: %YLEG%
ShortLegend[%KEY%]: %SHORT%
LegendI[%KEY%]: %IN%
LegendO[%KEY%]: %OUT%
Legend1[%KEY%]: %INLONG%
Legend2[%KEY%]: %OUTLONG%
ThreshMinI[%KEY%]: %MINI%
ThreshMaxI[%KEY%]: %MAXI%
ThreshProgI[%KEY%]: %PROGI%
ThreshMinO[%KEY%]: %MINO%
ThreshMaxO[%KEY%]: %MAXO%
ThreshProgO[%KEY%]: %PROGO%
WithPeak[%KEY%]: ymw
Timezone[%KEY%]: MST7MDT
