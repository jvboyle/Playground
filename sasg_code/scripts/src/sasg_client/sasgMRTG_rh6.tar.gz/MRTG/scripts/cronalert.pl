#!/usr/bin/perl

open MAIL, "|mail -s $ARGV[0] blacksmith\@us.ibm.com";
print MAIL "There are currently $ARGV[2] cron jobs running.\n";
close MAIL;
