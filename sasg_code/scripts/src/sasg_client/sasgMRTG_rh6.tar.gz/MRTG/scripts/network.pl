#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

$if = shift || "eth0";

eval
{

  @dev = `cat /proc/net/dev|grep $if`;

  @F = split(/[: ]+/,$dev[0]);

  print "$F[2]\n$F[10]\n";
  print localtime()."\n";
  print "Network Traffic $if\n";
};

if ($@ =~ /timeout/) { exit };
