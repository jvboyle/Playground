#!/usr/bin/perl

$SIG{ALRM} = sub { die "timeout" };
alarm(30);

eval
{

  @result = `/sbin/iptables -L`;

  if (@result > 5) {
      $x = 100;
      $y = 0;
  } else {
      $x = 0;
      $y = 100;
  }

  print "$y\n$x\n";
  print "NA\n";
  print "Iptables Status\n";
};

if ($@ =~ /timeout/) { exit };
