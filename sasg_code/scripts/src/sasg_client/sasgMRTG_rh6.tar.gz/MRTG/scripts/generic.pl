#!/usr/bin/perl 

use lib "/sasg/MRTG/scripts";
use lib "/sasg/MRTG/lib";
use If;
use Static;
use Page;
use Fs;

$ENV{LD_LIBRARY_PATH} = "/sasg/MRTG/lib";
$ENV{LIB_PATH} = "/sasg/MRTG/lib";

$ENV{LANG} = "en_US";

open LOCK,">mrtg.lock";
flock(LOCK,2) or die;

($host = `hostname`) =~ s/\.[^.]+//g;
$basedir = "/sasg/MRTG"; 
@cells = (static);

umask  022;

for ($i = 1; $i< @cells; $i+=4)
{
  $html .= "<TR>\n";
  $html .= $cells[$i];
  $html .= $cells[$i+2];
  $html .= "\n</TR>\n";
}

for ($i = 0; $i< @cells; $i+=2)
{
   push @cfgs,"$basedir/conf/$cells[$i].cfg";
}

@DATA = <DATA>;

for (@DATA)
{
   s/%ROWS%/$html/;
   
}

$indexdir = "/sasg/MRTG/stats";

open INDEX, ">$indexdir/index.html" or die "$indexdir/index.html: $!";
flock(INDEX,2);
print INDEX @DATA;
close INDEX;

system "/sasg/MRTG/bin/mrtg $_&" for @cfgs;

close LOCK;
__DATA__
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
    <TITLE>MRTG Index Page</TITLE>
</HEAD>

<BODY bgcolor="#ffffff" text="#000000" link="#000000" vlink="#000000" alink="#000000">
<H1>MRTG Index Page</H1>

<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=10>


%ROWS%


</TABLE>
<BR>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR>
    <TD WIDTH=63><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-l.png" WIDTH=63 HEIGHT=25 ALT="MRTG"></A></TD>
    <TD WIDTH=25><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-m.png" WIDTH=25 HEIGHT=25 ALT=""></A></TD>
    <TD WIDTH=388><A
    HREF="http://www.ee.ethz.ch/~oetiker/webtools/mrtg/mrtg.html"><IMG
    BORDER=0 SRC="mrtg-r.png" WIDTH=388 HEIGHT=25
    ALT="Multi Router Traffic Grapher"></A></TD>
  </TR>
</TABLE>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
  <TR VALIGN=top>
  <TD WIDTH=88 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
  version 2.9.4</FONT></TD>
  <TD WIDTH=388 ALIGN=RIGHT><FONT FACE="Arial,Helvetica" SIZE=2>
  <A HREF="http://www.ee.ethz.ch/~oetiker/">Tobias Oetiker</A>
  <A HREF="mailto:oetiker@ee.ethz.ch">&lt;oetiker@ee.ethz.ch&gt;</A>
  and&nbsp;<A HREF="http://www.bungi.com/">Dave&nbsp;Rand</A>&nbsp;<A HREF="mailto:dlr@bungi.com">&lt;dlr@bungi.com&gt;</A></FONT>
  </TD>
</TR>
</TABLE>
</BODY>
</HTML>
