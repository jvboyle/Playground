package Cell;
use Exporter;

use strict;
use vars qw(@EXPORT @ISA);
@ISA = qw(Exporter);
@EXPORT = qw(cell);

my @DATA = <DATA>;

sub cell
{
  my %args = @_;
  my ($key,$title) = ($args{Key},$args{Title});
  my @cell = @DATA;
  for (@cell)
  {
    s/%KEY%/$key/g;
    s/%TITLE%/$title/g; 
  }
  return join '',@cell;
}

1;

__DATA__
<TD><DIV><B>%TITLE%</B></DIV>
<DIV><A HREF="%KEY%.html "><IMG BORDER=1 ALT="%KEY% Graph" SRC="%KEY%-day.png"></A>
<BR>
<SMALL><!--#flastmod file="%KEY%.html" --></SMALL></DIV>
</TD>
